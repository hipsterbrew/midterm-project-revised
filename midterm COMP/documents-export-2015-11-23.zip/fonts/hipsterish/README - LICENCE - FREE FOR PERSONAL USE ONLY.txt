�Hello I�m Flo�s Font�
End User License Agreement: Free for personnal use

This End-User License Agreement ("EULA") is a legal agreement between you (either an individual or a single entity) and "Hello I'm Flo" for the digital typeface software - hereafter �fonts� included in this package: 

Hipsterish

The font included is protected by copyright laws and international copyright treaties, as well as other intellectual property laws and treaties.
 
These fonts are licensed to you for personal / noncommercial use only. You're granted the following rights: 

01] You may install and use an unlimited number of copies of the fonts. 
02] You can make archival copies of the fonts for your own purposes. 
03] You may modify the fonts for your own purposes, but the copyright remains with "Hello I'm FLo" and you are not allowed to distribuite renamed, edited or derivative works, either for profit or not.

To acquire a complete licence for commercial use (allowing file release to a prepress bureau and embedding in other software files, such as Portable Document Format (PDF) or Flash files), you can contact us at contact@helloimflo.net, or buy this character online through our resellers:
www.signumart.com
www.buyafont.com

"Hello I'm Flo" expressly disclaims any warranty for the fonts. The fonts and any related documentation is provided "as is" without warranty of
any kind, either express or implied, including, without limitation, the implied warranties or merchantability, fitness for a particular purpose,
or noninfringement. The entire risk arising out of use or performance of the fonts remains with you. Copies of the fonts may not be distributed
or shared in any way (for profit or free of charge) either on a standalone basis or included as part of your own product.

In no event shall "Hello I'm Flo" or its suppliers be liable for any damages whatsoever (including, without limitation, damages for loss of business profits, business interruption, loss of business information, or any other pecuniary loss) arising out of the use of or inability to use this product, even if "Hello I'm Flo" has been advised of the possibility of such damages. Because some states/jurisdictions do not allow the exclusion or limitation of liability for consequential or incidental damages, the above limitation may not apply to you.

QUESTIONS :
Should you have any questions concerning this EULA, please contact "Hello I'm Flo" directly at this address : contact@helloimflo.net
